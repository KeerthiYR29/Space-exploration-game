## Space Shooter Game using Javascript and CSS

The game is a single player game which involves the player controlling a spaceship and shooting enemies.
You can control the spaceship using the arrow keys.
The spacebar key is used to shoot.
The player dies on making contact with an enemy.
The game speeds up on regular intervals to increase the difficulty
The player is given three lives to achieve the highest score possible.

<p align="center">
<img src=https://github.com/Abilityguy/Space-Shooter/blob/master/Images/Screenshot.png>
</p>

<br>
You can play the game at: https://abilityguy.github.io/Space-Shooter/space_shooter.html
